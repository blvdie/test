﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace BlvdesStore
{
    public partial class EditProductWindow : Window
    {
        private string _connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BlvdesStoreDB;Integrated Security=True;";
        private int _skinId;

        public EditProductWindow(int skinId)
        {
            InitializeComponent();
            _skinId = skinId;
            LoadData();
            LoadFilters();
        }

        private void LoadData()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = @"
                        SELECT Name, Price, IconUrl, HeroId, SlotId, RarityId, HoldPeriodId
                        FROM DotaSkins WHERE SkinId = @SkinId";

                    using (var cmd = new SqlCommand(query, connection))
                    {
                        cmd.Parameters.AddWithValue("@SkinId", _skinId);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                NameBox.Text = reader["Name"].ToString();
                                PriceBox.Text = reader.GetDecimal(reader.GetOrdinal("Price")).ToString();
                                IconUrlBox.Text = reader["IconUrl"]?.ToString();

                                if (reader["HeroId"] != DBNull.Value)
                                    HeroCombo.SelectedValue = reader.GetInt32(reader.GetOrdinal("HeroId"));

                                if (reader["SlotId"] != DBNull.Value)
                                    SlotCombo.SelectedValue = reader.GetInt32(reader.GetOrdinal("SlotId"));

                                if (reader["RarityId"] != DBNull.Value)
                                    RarityCombo.SelectedValue = reader.GetInt32(reader.GetOrdinal("RarityId"));

                                if (reader["HoldPeriodId"] != DBNull.Value)
                                    HoldCombo.SelectedValue = reader.GetInt32(reader.GetOrdinal("HoldPeriodId"));
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void LoadFilters()
        {
            LoadHeroes();
            LoadSlots();
            LoadRarities();
            LoadHoldPeriods();
        }

        private void LoadHeroes()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT HeroId, HeroName FROM DotaHeroes", connection);
                HeroCombo.ItemsSource = cmd.ExecuteReader().Cast<Hero>().ToList();
            }
        }

        private void LoadSlots()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT SlotId, SlotName FROM DotaSlots", connection);
                SlotCombo.ItemsSource = cmd.ExecuteReader().Cast<Slot>().ToList();
            }
        }

        private void LoadRarities()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT RarityId, RarityName FROM DotaRarities", connection);
                RarityCombo.ItemsSource = cmd.ExecuteReader().Cast<Rarity>().ToList();
            }
        }

        private void LoadHoldPeriods()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT HoldPeriodId, Description FROM HoldPeriods", connection);
                HoldCombo.ItemsSource = cmd.ExecuteReader().Cast<HoldPeriod>().ToList();
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (!decimal.TryParse(PriceBox.Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Введите корректную цену");
                return;
            }

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    var cmd = new SqlCommand(@"
                        UPDATE DotaSkins SET
                        Name = @name,
                        Price = @price,
                        IconUrl = @icon,
                        HeroId = @hero,
                        SlotId = @slot,
                        RarityId = @rarity,
                        HoldPeriodId = @hold
                        WHERE SkinId = @skinId", connection);

                    cmd.Parameters.AddWithValue("@name", NameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@icon", IconUrlBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@hero", HeroCombo.SelectedValue ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@slot", SlotCombo.SelectedValue ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@rarity", RarityCombo.SelectedValue ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@hold", HoldCombo.SelectedValue ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@skinId", _skinId);

                    cmd.ExecuteNonQuery();
                    DialogResult = true;
                    Close();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка при редактировании: " + ex.Message);
            }
        }

        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb.Text == "Название скина" || tb.Text == "Цена" || tb.Text == "URL изображения")
            {
                tb.Text = "";
                tb.Foreground = Brushes.White;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (string.IsNullOrWhiteSpace(tb.Text))
            {
                if (tb == NameBox) tb.Text = "Название скина";
                else if (tb == PriceBox) tb.Text = "Цена";
                else if (tb == IconUrlBox) tb.Text = "URL изображения";

                tb.Foreground = Brushes.Gray;
            }
        }

        private void PriceBox_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, e.Text.Length - 1))
                e.Handled = true;
        }
    }

}