﻿using System.Collections.Generic;

namespace BlvdesStore.Services
{
    public static class CartService
    {
        private static Dictionary<int, int> _cart = new Dictionary<int, int>();

        public static void AddToCart(int skinId)
        {
            if (_cart.ContainsKey(skinId))
                _cart[skinId]++;
            else
                _cart.Add(skinId, 1);
        }

        public static void RemoveFromCart(int skinId)
        {
            if (_cart.ContainsKey(skinId))
                _cart.Remove(skinId);
        }

        public static Dictionary<int, int> GetCart() => _cart;
    }
}