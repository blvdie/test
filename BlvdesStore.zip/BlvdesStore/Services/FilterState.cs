﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlvdesStore.Services
{
    public static class FilterState
    {
        public static string SearchQuery { get; set; }
        public static List<int> SelectedHeroes { get; set; } = new List<int>();
        public static List<int> SelectedSlots { get; set; } = new List<int>();
        public static List<int> SelectedRarities { get; set; } = new List<int>();
        public static List<int> SelectedHolds { get; set; } = new List<int>();
        public static decimal? MinPrice { get; set; }
        public static decimal? MaxPrice { get; set; }
        public static bool SortAsc { get; set; }
        public static bool SortDesc { get; set; }
    }
}
