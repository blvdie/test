﻿using BlvdesStore.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Security.Claims;
using System.Security.Policy;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using static System.Net.Mime.MediaTypeNames;
using System.Windows.Media.Media3D;
using System.Xml.Linq;

namespace BlvdesStore
{
    public partial class BuyCS : Page
    {
        private List<CSSkin> _products = new List<CSSkin>();
        private Dictionary<int, int> _cartItems = new Dictionary<int, int>();
        private string _connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BlvdesStoreDB;Integrated Security=True;";
        private const int PageSize = 15;
        public bool IsAdmin { get; set; }

        public BuyCS()
        {
            InitializeComponent();
            DataContext = this;
            Loaded += OnPageLoaded;
        }

        private void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            LoadUserInfo();
            CheckAdminStatus();
            LoadFilters();
            LoadProducts();
        }

        #region Пользователь
        private void LoadUserInfo()
        {
            var user = GetCurrentUser();
            if (user != null)
            {
                UserNameText.Text = user.NickName;
            }
        }

        private Models.User GetCurrentUser()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT UserId, NickName FROM Users WHERE UserId = @UserId";

                    using (var cmd = new SqlCommand(query, connection))
                    {
                        var userId = AppConnect.CurrentUser?.UserId ?? 1;
                        cmd.Parameters.AddWithValue("@UserId", userId);

                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new Models.User
                                {
                                    UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                                    NickName = reader.GetString(reader.GetOrdinal("NickName"))
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пользователя: " + ex.Message);
            }
            return null;
        }

        private void CheckAdminStatus()
        {
            IsAdmin = AppConnect.CurrentUser?.RoleId == 1;
        }
        #endregion

        #region Фильтры
        private void LoadFilters()
        {
            LoadTypes();
            LoadSubcategories();
            LoadHoldPeriods();
        }

        private void LoadTypes()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT TypeId, TypeName FROM FilterCS";
                    TypesList.Items.Clear();
                    using (var reader = new SqlCommand(query, connection).ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var type = new Models.FilterType
                            {
                                TypeId = reader.GetInt32(0),
                                TypeName = reader.GetString(1)
                            };
                            var cb = new CheckBox { Content = type.TypeName, Tag = type.TypeId };
                            cb.Checked += (s, e) => ApplyFilters();
                            cb.Unchecked += (s, e) => ApplyFilters();
                            TypesList.Items.Add(cb);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки типов: " + ex.Message);
            }
        }

        private void LoadSubcategories()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT SubcategoryId, SubcategoryName FROM SubcategoryCS";
                    SubcategoriesList.Items.Clear();
                    using (var reader = new SqlCommand(query, connection).ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var subcategory = new Models.SubcategoryCS
                            {
                                SubcategoryId = reader.GetInt32(0),
                                SubcategoryName = reader.GetString(1)
                            };
                            var cb = new CheckBox { Content = subcategory.SubcategoryName, Tag = subcategory.SubcategoryId };
                            cb.Checked += (s, e) => ApplyFilters();
                            cb.Unchecked += (s, e) => ApplyFilters();
                            SubcategoriesList.Items.Add(cb);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки подкатегорий: " + ex.Message);
            }
        }

        private void LoadHoldPeriods()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT HoldPeriodId, Description FROM HoldPeriods";
                    HoldList.Items.Clear();
                    using (var reader = new SqlCommand(query, connection).ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            var hold = new Models.HoldPeriod
                            {
                                HoldPeriodId = reader.GetInt32(0),
                                Description = reader.GetString(1)
                            };
                            var cb = new CheckBox { Content = hold.Description, Tag = hold.HoldPeriodId };
                            cb.Checked += (s, e) => ApplyFilters();
                            cb.Unchecked += (s, e) => ApplyFilters();
                            HoldList.Items.Add(cb);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки холдов: " + ex.Message);
            }
        }
        #endregion

        #region Товары
        private void LoadProducts(int page = 1)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string baseQuery = "SELECT SkinId, Name, Price, IconUrl FROM CSSkins WHERE 1=1";
                    var filters = new List<string>();
                    var parameters = new List<SqlParameter>();

                    // Поиск по названию
                    if (!string.IsNullOrEmpty(SearchBox.Text) && SearchBox.Text != "Поиск...")
                    {
                        filters.Add("Name LIKE '%' + @search + '%'");
                        parameters.Add(new SqlParameter("@search", SearchBox.Text));
                    }

                    // Типы
                    var selectedTypes = TypesList.Items.OfType<CheckBox>()
                        .Where(cb => cb.IsChecked == true)
                        .Select(cb => (int?)cb.Tag)
                        .ToList();
                    if (selectedTypes.Count > 0)
                        filters.Add($"TypeId IN ({string.Join(",", selectedTypes)})");

                    // Подкатегории
                    var selectedSubcategories = SubcategoriesList.Items.OfType<CheckBox>()
                        .Where(cb => cb.IsChecked == true)
                        .Select(cb => (int?)cb.Tag)
                        .ToList();
                    if (selectedSubcategories.Count > 0)
                        filters.Add($"SubcategoryId IN ({string.Join(",", selectedSubcategories)})");

                    // Холды
                    var selectedHolds = HoldList.Items.OfType<CheckBox>()
                        .Where(cb => cb.IsChecked == true)
                        .Select(cb => (int?)cb.Tag)
                        .ToList();
                    if (selectedHolds.Count > 0)
                        filters.Add($"HoldPeriodId IN ({string.Join(",", selectedHolds)})");

                    // Цена
                    if (decimal.TryParse(MinPriceBox.Text, out decimal minPrice))
                    {
                        filters.Add("Price >= @minPrice");
                        parameters.Add(new SqlParameter("@minPrice", minPrice));
                    }
                    if (decimal.TryParse(MaxPriceBox.Text, out decimal maxPrice))
                    {
                        filters.Add("Price <= @maxPrice");
                        parameters.Add(new SqlParameter("@maxPrice", maxPrice));
                    }

                    if (filters.Count > 0)
                        baseQuery += " AND " + string.Join(" AND ", filters);

                    // Сортировка
                    if (SortToggleAsc?.IsChecked == true)
                        baseQuery += " ORDER BY Price ASC";
                    else if (SortToggleDesc?.IsChecked == true)
                        baseQuery += " ORDER BY Price DESC";
                    else
                        baseQuery += " ORDER BY SkinId DESC";

                    // Пагинация
                    int offset = (page - 1) * PageSize;
                    baseQuery += $" OFFSET {offset} ROWS FETCH NEXT {PageSize} ROWS ONLY";

                    using (var cmd = new SqlCommand(baseQuery, connection))
                    {
                        cmd.Parameters.AddRange(parameters.ToArray());
                        using (var reader = cmd.ExecuteReader())
                        {
                            _products.Clear();
                            while (reader.Read())
                            {
                                _products.Add(new Models.CSSkin
                                {
                                    SkinId = reader.GetInt32(reader.GetOrdinal("SkinId")),
                                    Name = reader.GetString(reader.GetOrdinal("Name")),
                                    Price = reader.GetDecimal(reader.GetOrdinal("Price")),
                                    ImageSource = reader.IsDBNull(reader.GetOrdinal("IconUrl"))
                                        ? "/Resources/default_skin.png"
                                        : reader.GetString(reader.GetOrdinal("IconUrl"))
                                });
                            }
                        }
                    }

                    ProductsList.ItemsSource = _products;
                    UpdatePaginationButtons(page);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки скинов CS: " + ex.Message);
            }
        }

        private void UpdatePaginationButtons(int page = 1)
        {
            PaginationPanel.Children.Clear();

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string countQuery = "SELECT COUNT(*) FROM CSSkins WHERE 1=1";
                    var filters = new List<string>();
                    var parameters = new List<SqlParameter>();

                    if (!string.IsNullOrEmpty(SearchBox.Text) && SearchBox.Text != "Поиск...")
                    {
                        filters.Add("Name LIKE '%' + @search + '%'");
                        parameters.Add(new SqlParameter("@search", SearchBox.Text));
                    }

                    var selectedTypes = TypesList.Items.OfType<CheckBox>()
                        .Where(cb => cb.IsChecked == true)
                        .Select(cb => (int?)cb.Tag)
                        .ToList();
                    if (selectedTypes.Count > 0)
                        filters.Add($"TypeId IN ({string.Join(",", selectedTypes)})");

                    var selectedSubcategories = SubcategoriesList.Items.OfType<CheckBox>()
                        .Where(cb => cb.IsChecked == true)
                        .Select(cb => (int?)cb.Tag)
                        .ToList();
                    if (selectedSubcategories.Count > 0)
                        filters.Add($"SubcategoryId IN ({string.Join(",", selectedSubcategories)})");

                    var selectedHolds = HoldList.Items.OfType<CheckBox>()
                        .Where(cb => cb.IsChecked == true)
                        .Select(cb => (int?)cb.Tag)
                        .ToList();
                    if (selectedHolds.Count > 0)
                        filters.Add($"HoldPeriodId IN ({string.Join(",", selectedHolds)})");

                    if (filters.Count > 0)
                        countQuery += " AND " + string.Join(" AND ", filters);

                    using (var countCmd = new SqlCommand(countQuery, connection))
                    {
                        countCmd.Parameters.AddRange(parameters.ToArray());
                        int totalItems = (int)countCmd.ExecuteScalar();
                        int totalPages = (int)Math.Ceiling(totalItems / (double)PageSize);

                        for (int i = 1; i <= totalPages; i++)
                        {
                            Button btn = new Button
                            {
                                Content = i.ToString(),
                                Width = 30,
                                Height = 30,
                                BorderBrush = Brushes.Purple,
                                Margin = new Thickness(2)
                            };
                            btn.Click += (s, e) => LoadProducts(i);
                            PaginationPanel.Children.Add(btn);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка пагинации: " + ex.Message);
            }
        }
        #endregion

        #region Обработчики событий
        private void SearchBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb != null && tb.Text == "Поиск...")
            {
                tb.Text = "";
                tb.Foreground = Brushes.White;
            }
        }

        private void SearchBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb != null && string.IsNullOrWhiteSpace(tb.Text))
            {
                tb.Text = "Поиск...";
                tb.Foreground = Brushes.Gray;
            }
        }

        private void OnFilterBoxGotFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb != null && (tb.Text == "Цена от" || tb.Text == "Цена до"))
            {
                tb.Text = "";
                tb.Foreground = Brushes.White;
            }
        }

        private void OnFilterBoxLostFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as TextBox;
            if (tb != null && string.IsNullOrWhiteSpace(tb.Text))
            {
                if (tb.Name.Contains("Min")) tb.Text = "Цена от";
                else tb.Text = "Цена до";
                tb.Foreground = Brushes.Gray;
            }
        }

        private void MinPriceBox_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, e.Text.Length - 1))
                e.Handled = true;
        }

        private void MaxPriceBox_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, e.Text.Length - 1))
                e.Handled = true;
        }

        private void SortToggleAsc_Click(object sender, RoutedEventArgs e)
        {
            SortToggleDesc.IsChecked = false;
            LoadProducts();
        }

        private void SortToggleDesc_Click(object sender, RoutedEventArgs e)
        {
            SortToggleAsc.IsChecked = false;
            LoadProducts();
        }

        private void SearchBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            LoadProducts();
        }

        private void ResetFilters_Click(object sender, RoutedEventArgs e)
        {
            foreach (var item in TypesList.Items.OfType<CheckBox>()) item.IsChecked = false;
            foreach (var item in SubcategoriesList.Items.OfType<CheckBox>()) item.IsChecked = false;
            foreach (var item in HoldList.Items.OfType<CheckBox>()) item.IsChecked = false;
            MinPriceBox.Text = "Цена от";
            MaxPriceBox.Text = "Цена до";
            LoadProducts();
        }

        private void ApplyFilters()
        {
            LoadProducts();
        }
        #endregion

        #region Админские функции

        private void AddProduct_Click(object sender, RoutedEventArgs e)
        {
            var addWindow = new AddProductWindow();
            if (addWindow.ShowDialog() == true)
            {
                LoadProducts(); // обновляем список товаров
            }
        }

        private void EditProduct_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && int.TryParse(btn.Tag.ToString(), out int skinId))
            {
                var editWindow = new EditProductWindow(skinId);
                if (editWindow.ShowDialog() == true)
                {
                    LoadProducts(); // обновляем товары
                }
            }
        }

        private void DeleteProduct_Click(object sender, RoutedEventArgs e)
        {
            if (sender is Button btn && int.TryParse(btn.Tag.ToString(), out int skinId))
            {
                if (MessageBox.Show("Вы уверены, что хотите удалить этот скин?", "Подтверждение", MessageBoxButton.YesNo) == MessageBoxResult.Yes)
                {
                    try
                    {
                        using (var connection = new SqlConnection(_connectionString))
                        {
                            connection.Open();
                            var cmd = new SqlCommand("DELETE FROM CSSkins WHERE SkinId = @SkinId", connection);
                            cmd.Parameters.AddWithValue("@SkinId", skinId);
                            cmd.ExecuteNonQuery();
                            LoadProducts(); // обновляем список
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Ошибка удаления: " + ex.Message);
                    }
                }
            }
        }

        #endregion

        #region Навигация
        private void GoToAccount_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new Account());
        private void GoToStart_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new Start());
        private void AddToCart_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new Cart());
        private void GoToBuyDota_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new BuyDota());
        private void Logout_Click(object sender, RoutedEventArgs e) => NavigationService.Navigate(new Start());
        #endregion
    }
}
