﻿using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using BlvdesStore.Models;

namespace BlvdesStore
{
    public partial class BuyDota : Page
    {
        private string _connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BlvdesStoreDB;Integrated Security=True;";
        public bool IsAdmin { get; set; }

        public BuyDota() : base()
        {


        private User GetCurrentUser()
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    string query = "SELECT UserId, NickName, RoleId, Balance FROM Users WHERE UserId = @UserId";
                    using (var cmd = new SqlCommand(query, connection))
                    {
                        int userId = AppConnect.CurrentUser.UserId;
                        cmd.Parameters.AddWithValue("@UserId", userId);
                        using (var reader = cmd.ExecuteReader())
                        {
                            if (reader.Read())
                            {
                                return new User
                                {
                                    UserId = reader.GetInt32(0),
                                    NickName = reader.GetString(1),
                                    RoleId = reader.GetInt32(2),
                                    Balance = reader.GetDecimal(3)
                                };
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Ошибка загрузки пользователя: " + ex.Message);
            }

            return null;
        }

        private void CheckAdminStatus()
        {
            IsAdmin = AppConnect.CurrentUser.RoleId == 1;
        }
            // ❗️Проверяем сразу
            if (AppConnect.CurrentUser == null)
            {
                MessageBox.Show("Ошибка: пользователь не авторизован.");
                NavigationService?.Navigate(new Start());
                return;
            }

            InitializeComponent();
            DataContext = this;

            Loaded += OnPageLoaded;
        }

        private void OnPageLoaded(object sender, RoutedEventArgs e)
        {
            LoadUserInfo();
            CheckAdminStatus();
        }

        private void LoadUserInfo()
        {
            var user = GetCurrentUser();
            if (user != null)
            {
                UserNameText.Text = user.NickName;
                UserBalanceText.Text = $"Баланс: ₽{user.Balance:F2}";
            }
        }


    }
}