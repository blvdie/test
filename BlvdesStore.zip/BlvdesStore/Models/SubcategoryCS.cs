﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlvdesStore.Models
{
    public class SubcategoryCS
    {
        public int SubcategoryId { get; set; }
        public string SubcategoryName { get; set; }
    }
}