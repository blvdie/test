﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlvdesStore.Models
{
    public class Slot
    {
        public int SlotId { get; set; }
        public string SlotName { get; set; }
    }
}
