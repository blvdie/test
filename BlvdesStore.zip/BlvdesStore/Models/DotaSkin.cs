﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlvdesStore.Models
{
    public class DotaSkin
    {
        public int SkinId { get; set; }
        public string Name { get; set; }
        public decimal Price { get; set; }
        public string ImageSource { get; set; }

        private bool _isInCart;
        public bool IsInCart
        {
            get => _isInCart;
            set
            {
                _isInCart = value;
                OnPropertyChanged(nameof(IsInCart));
            }
        }

        private int _quantityInCart;
        public int QuantityInCart
        {
            get => _quantityInCart;
            set
            {
                _quantityInCart = value;
                OnPropertyChanged(nameof(QuantityInCart));
            }
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected void OnPropertyChanged(string propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }
    
}
}
