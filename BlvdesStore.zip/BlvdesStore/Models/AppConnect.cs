﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BlvdesStore.Models;


namespace BlvdesStore
{
    public static class AppConnect
    {
        public static User CurrentUser { get; set; }
    }
}