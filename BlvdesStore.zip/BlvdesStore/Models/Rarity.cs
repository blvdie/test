﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlvdesStore.Models
{
    public class Rarity
    {
        public int RarityId { get; set; }
        public string RarityName { get; set; }
    }
}
