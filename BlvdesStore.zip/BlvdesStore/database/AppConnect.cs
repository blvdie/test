﻿using System.Data.SqlClient;

namespace BlvdesStore
{
    public static class AppConnect
    {
        public static Models.User CurrentUser { get; set; }
    }

    public class UserSession
    {
        public int UserId { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public decimal Balance { get; set; }
        public byte[] Avatar { get; set; }
        public string Role { get; set; }

        // Добавить:
        public int RoleId { get; set; } // ← добавлено
            }
    AppConnect.CurrentUser = new User
    {
    UserId = ...,
    NickName = ...,
    RoleId = ...,
    Balance = ...
    };
}