﻿using System;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;

namespace BlvdesStore
{
    public partial class AddProductWindow : Window
    {
        private string _connectionString = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=BlvdesStoreDB;Integrated Security=True;";

        public AddProductWindow()
        {
            InitializeComponent();
            LoadFilters();
        }

        private void LoadFilters()
        {
            LoadHeroes();
            LoadSlots();
            LoadRarities();
            LoadHoldPeriods();
        }

        private void LoadHeroes()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT HeroId, HeroName FROM DotaHeroes", connection);
                HeroCombo.ItemsSource = cmd.ExecuteReader().Cast<Hero>().ToList();
            }
        }

        private void LoadSlots()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT SlotId, SlotName FROM DotaSlots", connection);
                SlotCombo.ItemsSource = cmd.ExecuteReader().Cast<Slot>().ToList();
            }
        }

        private void LoadRarities()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT RarityId, RarityName FROM DotaRarities", connection);
                RarityCombo.ItemsSource = cmd.ExecuteReader().Cast<Rarity>().ToList();
            }
        }

        private void LoadHoldPeriods()
        {
            using (var connection = new SqlConnection(_connectionString))
            {
                connection.Open();
                var cmd = new SqlCommand("SELECT HoldPeriodId, Description FROM HoldPeriods", connection);
                HoldCombo.ItemsSource = cmd.ExecuteReader().Cast<HoldPeriod>().ToList();
            }
        }

        // --- Обработчики событий ---
        public AddProductWindow(int skinId)
        {
            InitializeComponent();
            LoadData(skinId);
        }

        private void LoadData(int skinId)
        {
            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();
                    var cmd = new SqlCommand("SELECT Name, Price, IconUrl, HeroId, SlotId, RarityId, HoldPeriodId FROM DotaSkins WHERE SkinId = @SkinId", connection);
                    cmd.Parameters.AddWithValue("@SkinId", skinId);

                    using (var reader = cmd.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            NameBox.Text = reader.GetString(reader.GetOrdinal("Name"));
                            PriceBox.Text = reader.GetDecimal(reader.GetOrdinal("Price")).ToString();
                            IconUrlBox.Text = reader.IsDBNull(reader.GetOrdinal("IconUrl"))
                                ? null
                                : reader.GetString(reader.GetOrdinal("IconUrl"));

                            HeroCombo.SelectedValue = reader["HeroId"] as int?;
                            SlotCombo.SelectedValue = reader["SlotId"] as int?;
                            RarityCombo.SelectedValue = reader["RarityId"] as int?;
                            HoldCombo.SelectedValue = reader["HoldPeriodId"] as int?;
                        }
                    }
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Ошибка загрузки данных: " + ex.Message);
            }
        }

        private void Save_Click(object sender, RoutedEventArgs e)
        {
            if (!decimal.TryParse(PriceBox.Text, out decimal price) || price <= 0)
            {
                MessageBox.Show("Введите корректную цену");
                return;
            }

            try
            {
                using (var connection = new SqlConnection(_connectionString))
                {
                    connection.Open();

                    var cmd = new SqlCommand(@"
                        INSERT INTO DotaSkins (Name, Price, IconUrl, HeroId, SlotId, RarityId, HoldPeriodId, GameId)
                        VALUES (@name, @price, @icon, @hero, @slot, @rarity, @hold, 1)", connection);

                    cmd.Parameters.AddWithValue("@name", NameBox.Text.Trim());
                    cmd.Parameters.AddWithValue("@price", price);
                    cmd.Parameters.AddWithValue("@icon", IconUrlBox.Text?.Trim() ?? DBNull.Value.ToString());
                    cmd.Parameters.AddWithValue("@hero", HeroCombo.SelectedValue ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@slot", SlotCombo.SelectedValue ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@rarity", RarityCombo.SelectedValue ?? DBNull.Value);
                    cmd.Parameters.AddWithValue("@hold", HoldCombo.SelectedValue ?? DBNull.Value);

                    cmd.ExecuteNonQuery();
                    DialogResult = true;
                    Close();
                }
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("Ошибка при добавлении товара: " + ex.Message);
            }
        }

        // --- Placeholder текст ---
        private void TextBox_GotFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as System.Windows.Controls.TextBox;
            if (tb != null && (tb.Text == "Название скина" || tb.Text == "Цена" || tb.Text == "URL изображения"))
            {
                tb.Text = "";
                tb.Foreground = System.Windows.Media.Brushes.White;
            }
        }

        private void TextBox_LostFocus(object sender, RoutedEventArgs e)
        {
            var tb = sender as System.Windows.Controls.TextBox;
            if (tb != null && string.IsNullOrWhiteSpace(tb.Text))
            {
                if (tb == NameBox) tb.Text = "Название скина";
                else if (tb == PriceBox) tb.Text = "Цена";
                else if (tb == IconUrlBox) tb.Text = "URL изображения";

                tb.Foreground = System.Windows.Media.Brushes.Gray;
            }
        }

        private void PriceBox_PreviewTextInput(object sender, System.Windows.Input.TextCompositionEventArgs e)
        {
            if (!char.IsDigit(e.Text, e.Text.Length - 1))
                e.Handled = true;
        }
    }

    #region Модели
    public class Hero
    {
        public int HeroId { get; set; }
        public string HeroName { get; set; }
    }

    public class Slot
    {
        public int SlotId { get; set; }
        public string SlotName { get; set; }
    }

    public class Rarity
    {
        public int RarityId { get; set; }
        public string RarityName { get; set; }
    }

    public class HoldPeriod
    {
        public int HoldPeriodId { get; set; }
        public string Description { get; set; }
    }
    #endregion
}