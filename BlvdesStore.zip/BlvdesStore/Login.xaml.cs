﻿using BlvdesStore.Models;
using System;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media.Animation;
using System.Windows.Threading;

namespace BlvdesStore
{
    public partial class Login : Page
    {
        private string connectionString = "Server=(localdb)\\MSSQLLocalDB;Database=BlvdesStoreDB;Trusted_Connection=True;";

        public Login()
        {
            InitializeComponent();
        }

        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameBox.Text.Trim();
            string password = PasswordBox.Password.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                ShowError("Введите логин и пароль");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                try
                {
                    conn.Open();
                    string query = @"
                SELECT UserId, Username, NickName, Email, RoleId, Balance 
                FROM Users 
                WHERE Username = @user AND Password = @pass";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@user", username);
                    cmd.Parameters.AddWithValue("@pass", password);

                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.Read())
                    {
                        // Устанавливаем пользователя до навигации
                        AppConnect.CurrentUser = new User
                        {
                            UserId = reader.GetInt32(reader.GetOrdinal("UserId")),
                            Username = reader.GetString(reader.GetOrdinal("Username")),
                            NickName = reader.GetString(reader.GetOrdinal("NickName")),
                            Email = reader.GetString(reader.GetOrdinal("Email")),
                            RoleId = reader.GetInt32(reader.GetOrdinal("RoleId")),
                            Balance = reader.GetDecimal(reader.GetOrdinal("Balance"))
                        };

                        reader.Close();

                        // Переход на главную страницу магазина
                        ((MainWindow)Application.Current.MainWindow).MainFrame.Navigate(new BuyDota());
                    }
                    else
                    {
                        ShowError("Неверный логин или пароль");
                    }
                }
                catch (Exception ex)
                {
                    ShowError("Ошибка подключения к базе данных: " + ex.Message);
                }
            }
        }

        #region === Методы для уведомлений ===
        public void ShowError(string message)
        {
            NotificationIcon.Text = "⚠";
            NotificationText.Text = message;
            NotificationText.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xD3, 0x2F, 0x2F));
            NotificationBorder.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xFE, 0xE6, 0xE6));
            NotificationBorder.BorderBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xFF, 0x73, 0x73));
            NotificationBorder.Visibility = Visibility.Visible;
            StartAutoHide();
        }

        public void ShowSuccess(string message)
        {
            NotificationIcon.Text = "✔";
            NotificationText.Text = message;
            NotificationText.Foreground = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x2E, 0x7D, 0x32));
            NotificationBorder.Background = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0xE8, 0xF5, 0xE9));
            NotificationBorder.BorderBrush = new System.Windows.Media.SolidColorBrush(System.Windows.Media.Color.FromRgb(0x81, 0xC7, 0x84));
            NotificationBorder.Visibility = Visibility.Visible;
            StartAutoHide();
        }

        private DispatcherTimer notificationTimer = new DispatcherTimer();

        private void StartAutoHide()
        {
            notificationTimer.Interval = TimeSpan.FromSeconds(5);
            notificationTimer.Tick += (s, ev) =>
            {
                HideNotification();
                notificationTimer.Stop();
            };
            notificationTimer.Start();
        }

        private void HideNotification()
        {
            DoubleAnimation fadeOut = new DoubleAnimation(0, TimeSpan.FromSeconds(0.5));
            fadeOut.Completed += (s, e) => NotificationBorder.Visibility = Visibility.Collapsed;
            NotificationBorder.BeginAnimation(OpacityProperty, fadeOut);
        }

        private void CloseNotificationBtn_Click(object sender, RoutedEventArgs e)
        {
            HideNotification();
            notificationTimer.Stop();
        }

        private void ShowPassword_Checked(object sender, RoutedEventArgs e)
        {
            bool isPasswordVisible = ShowPasswordCheck.IsChecked == true;
            if (isPasswordVisible)
            {
                PasswordTextBox.Text = PasswordBox.Password;
                PasswordBox.Visibility = Visibility.Collapsed;
                PasswordTextBox.Visibility = Visibility.Visible;
            }
            else
            {
                PasswordBox.Password = PasswordTextBox.Text;
                PasswordBox.Visibility = Visibility.Visible;
                PasswordTextBox.Visibility = Visibility.Collapsed;
            }
        }

        private void PasswordTextBox_PreviewMouseDown(object sender, MouseButtonEventArgs e)
        {
            e.Handled = true; // Запрет редактирования
        }

        private void GoToRegister(object sender, RoutedEventArgs e)
        {
            ((MainWindow)Application.Current.MainWindow).MainFrame.Navigate(new Register());
        }
        #endregion
    }
}