﻿using System.Windows;
using System.Windows.Input;

namespace BlvdesStore
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            Loaded += MainWindow_Loaded;
        }

        private void MainWindow_Loaded(object sender, RoutedEventArgs e)
        {
            // Загрузка начальной страницы (LogoPage)
            MainFrame.Navigate(new Logo());
        }

        private void Window_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.ChangedButton == MouseButton.Left)
            {
                this.DragMove();
            }
        }

        // Обработчик события для сворачивания окна
        private void Minimize_Click(object sender, RoutedEventArgs e)
        {
            this.WindowState = WindowState.Minimized;
        }

        // Обработчик события для разворачивания/сворачивания окна
        private void Maximize_Click(object sender, RoutedEventArgs e)
        {
            if (this.WindowState == WindowState.Normal)
            {
                this.WindowState = WindowState.Maximized;
            }
            else
            {
                this.WindowState = WindowState.Normal;
            }
        }

        // Обработчик события для закрытия окна
        private void Close_Click(object sender, RoutedEventArgs e)
        {
            this.Close();
        }
    }
}